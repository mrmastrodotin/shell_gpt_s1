#!/bin/bash

echo "Uninstalling shell_gpt_s1..."
pipx uninstall shell-gpt
echo "✓ Uninstalled successfully"
