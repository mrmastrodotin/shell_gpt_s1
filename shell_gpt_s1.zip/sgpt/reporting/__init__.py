"""
Reporting module
"""

from sgpt.reporting.generator import ReportGenerator

__all__ = ['ReportGenerator']
